package com.yasirkula.unity;

/**
 * Created by yasirkula on 19.02.2018.
 */

public interface NativeGalleryPermissionReceiver
{
	void OnPermissionResult( int result );
}
